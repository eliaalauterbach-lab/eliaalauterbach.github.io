# Berlin Guide App – Kostenlos online stellen

## So testest du die App auf deinem iPhone (5 Minuten)

### Schritt 1: GitHub Account erstellen
1. Öffne **github.com** in Safari
2. Tippe auf **"Sign up"**
3. Erstelle einen kostenlosen Account (E-Mail + Passwort)

### Schritt 2: Neues Repository erstellen
1. Nach dem Login, tippe oben rechts auf **"+"** → **"New repository"**
2. Name: `berlin-guide` (oder wie du willst)
3. Setze den Haken bei **"Add a README file"**
4. Tippe auf **"Create repository"**

### Schritt 3: HTML-Datei hochladen
1. Im Repository, tippe auf **"Add file"** → **"Upload files"**
2. Lade die Datei `Berlin_Guide___Leaflet_Map.html` hoch
3. **WICHTIG:** Benenne die Datei in `index.html` um
   - Oder: erstelle eine neue Datei namens `index.html` und kopiere den Inhalt rein
4. Tippe auf **"Commit changes"**

### Schritt 4: GitHub Pages aktivieren
1. Gehe zu **Settings** (Zahnrad-Symbol)
2. Scrolle links zu **"Pages"**
3. Unter **"Source"** wähle **"Deploy from a branch"**
4. Unter **"Branch"** wähle **"main"** und **"/ (root)"**
5. Tippe auf **"Save"**

### Schritt 5: Fertig!
- Nach 1-2 Minuten ist deine App live unter:
  `https://DEIN-USERNAME.github.io/berlin-guide/`
- Öffne diesen Link auf dem iPhone in Safari
- **Tipp:** Füge die Seite zum Home-Bildschirm hinzu (Teilen → "Zum Home-Bildschirm") – dann sieht es aus wie eine echte App!

---

## Was funktioniert alles?
- ✅ Karte mit Berlin-Sehenswürdigkeiten (sofort sichtbar)
- ✅ Automatisch neue POIs laden via Overpass API (weltweit!)
- ✅ Wikipedia-Infos bei Klick auf neue POIs
- ✅ Echte Fußwege über OSRM Routing
- ✅ Vorgefertigte Routen (Leicht, Mittel, ÖPNV)
- ✅ Eigene Tour erstellen + abbrechen
- ✅ GPS-Standort
- ✅ 4 Sprachen (DE/EN/FR/ES)
- ✅ Text-to-Speech
- ✅ Food-Spots

## Kosten
**0 €** – GitHub Pages, Overpass API, Wikipedia API und OSRM sind alle kostenlos.
